package com.tuyuservices.tuyu;

public class Service {

     int price;
     String serviceName;


    public Service(){
        //def construct
    }


    public Service(String serviceNamex, int pricex){
        serviceName = serviceNamex;
        price = pricex;
    }


}
