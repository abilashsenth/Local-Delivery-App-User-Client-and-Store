package com.tuyuservices.tuyu;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ListActivity extends AppCompatActivity {


    private static final String TAG = "Firebase" ;
    /**list of the serviceID
     * s01 - electrical
     * s02 - plumbing
     * s03 - carpentry
     * s04 - airconditioner
     * s05 - computer
     * s06 - cctv
     * s07-  pest control
     * s08 - deepcleaning
     * s09 - packers and movers
     * s10 - homeappliances
     */

    public String serviceTag;
    private int serviceId;
    int lengthCount =0;

    DatabaseReference databaseReference;
    String fBaseURL = "https://tuyuservices.firebaseio.com/";
    FirebaseDatabase mFirebaseDatabase;
    DatabaseReference mRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);
        databaseReference = FirebaseDatabase.getInstance().getReference();
        mFirebaseDatabase = FirebaseDatabase.getInstance();
        mRef = mFirebaseDatabase.getReference();
        serviceId = getIntent().getIntExtra("SERVICE_ID", 0);
        if(serviceId ==0){
            //error
            Log.e("Listactivity", "invalid ServiceID");
            Intent intent= new Intent(ListActivity.this, SplashActivity.class);
            startActivity(intent);

        }
        findService();





    }



    private void findService() {
        switch (serviceId){
            case R.id.s01:
                serviceTag = "electrical";
                retreiveData(serviceTag);
                break;
            case R.id.s02:
                serviceTag = "plumbing";
                retreiveData(serviceTag);


                break;
            case R.id.s03:
                serviceTag = "Carpentry";
                retreiveData(serviceTag);

                break;
            case R.id.s04:
                serviceTag = "Airconditioner";
                retreiveData(serviceTag);

                break;
            case R.id.s05:
                serviceTag = "Computers";
                retreiveData(serviceTag);

                break;
            case R.id.s06:
                serviceTag = "CCTV Services";
                retreiveData(serviceTag);

                break;



                //the rest of the services are for coming soon page
            case R.id.s07:
                break;
            case R.id.s08:
                break;
            case R.id.s09:
                break;
            case R.id.s10:
                break;





        }


    }

     String[] listString;


    private void retreiveData(final String x) {

        listString = new String[10];

        // Read from the database
        mRef.addValueEventListener(new ValueEventListener() {


            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // This method is called once with the initial value and again
                // whenever data at this location is updated.
                int count = 0;
                for(DataSnapshot ds : dataSnapshot.child(x).getChildren()){
                    String value = (String) ds.getKey();
                    listString[count] = value;
                    count++;
                    lengthCount++;

                }






            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
                Log.w(TAG, "Failed to read value.", error.toException());
            }
        });






    }


}
