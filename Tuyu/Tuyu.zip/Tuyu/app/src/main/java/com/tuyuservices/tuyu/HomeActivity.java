package com.tuyuservices.tuyu;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.TextView;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.bottomnavigation.BottomNavigationMenu;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

public class HomeActivity extends AppCompatActivity implements BottomNavigationView.OnNavigationItemSelectedListener {

    private static final int PERMISSION_FINE_LOCATION = 23;
    Boolean locationPermission;
    FrameLayout fragmentcontainer;
    BottomNavigationView bottomNavigationView;
    TextView addressLine1, addressLine2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        fragmentcontainer  = (FrameLayout) findViewById(R.id.fragment_container);
        bottomNavigationView = (BottomNavigationView) findViewById(R.id.bottomNavigationView);
        bottomNavigationView.setOnNavigationItemSelectedListener(this);
        loadFragment(new HomeFragment());
        checkLocationPermission();


    }


    private void checkLocationPermission() {

        if(ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED){
            //location permission required
            ActivityCompat.requestPermissions(this, new String[]
                    {Manifest.permission.ACCESS_FINE_LOCATION}, PERMISSION_FINE_LOCATION);

        }else{
            //location already granted
            checkCoarseAddress();
        }
    }


    private Location mLocation;
    private FusedLocationProviderClient fusedLocationClient;
    private void checkCoarseAddress() {
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
        fusedLocationClient.getLastLocation().addOnSuccessListener(this, new OnSuccessListener<Location>() {
            @Override
            public void onSuccess(Location location) {
                    if(location != null){
                        mLocation = location;
                        updateAddress();
                    }
            }
        });



    }

    private void updateAddress() {
        if(mLocation != null){

            Geocoder mGeocoder = new Geocoder(this, Locale.getDefault());
            try {
                List<Address> addresses = mGeocoder.getFromLocation(mLocation.getLatitude(), mLocation.getLongitude(), 1);
                String address1 = addresses.get(0).getAddressLine(0);
                String city = addresses.get(0).getLocality();
                //now onto updating onto the textviews
                Log.e("Address", address1);
                Log.e("Address", city);




            } catch (IOException e) {
                e.printStackTrace();
            }
        }



    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults){
        switch (requestCode){
            case PERMISSION_FINE_LOCATION:{
                if(grantResults.length >0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
                    //now that there's permission go for address check
                    checkCoarseAddress();
                }else{
                    //permission denied
                    //TODO HANDLE
                }
                return;
            }

        }
    }

    private boolean loadFragment(Fragment fragment){
        //swtichfragment
        if(fragment!=null){
            getSupportFragmentManager().
                    beginTransaction().
                    replace(R.id.fragment_container, fragment).
                    commit();
            return true;

        }
        return false;

    }


    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        //when a bottom navigation button is selected this is called
        Fragment fragment  = null;
        switch (menuItem.getItemId()){

            case R.id.action_home:
                fragment = new HomeFragment();
                break;
            case R.id.action_search:
                fragment = new SearchFragment();
                break;
            case R.id.action_cart:
                fragment = new CartFragment();
                break;
            case R.id.action_profile:
                fragment = new ProfileFragment();
                break;
        }


        return loadFragment(fragment);
    }

    public void openList(View v){
        int serviceID = v.getId();
        Intent listIntent = new Intent(HomeActivity.this, ListActivity.class);
        listIntent.putExtra("SERVICE_ID", serviceID);
        startActivity(listIntent);

    }
}
